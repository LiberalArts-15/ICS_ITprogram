from django.apps import AppConfig


class IdeaboardConfig(AppConfig):
    name = 'ideaboard'
